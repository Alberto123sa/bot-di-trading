#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MEXC SPOT CROSS-QUOTE FLAT-INVENTORY DEMO V10.1.1
==================================================
DEMO ONLY - NEVER SENDS ORDERS.

Design goals
------------
- Spot only: no futures, no leverage.
- USDC + USDT cross-quote market making.
- Small volatile inventory: target 2.5% of sleeve, soft 1.5-3.5%, hard 0.5-5.0%.
- Three maker levels per side.
- Cross fair: ASSET/USDC <-> ASSET/USDT using USDC/USDT.
- Explicit maker/taker fees and bootstrap costs.
- Strict virtual queue: depth ahead + tape participation cap.
- No retro-fills after API blackout.
- 403/429/timeout => freeze new simulation, preserve virtual orders, backoff.
- Global serialized REST budget and depth cache.
- Status/report threads continue printing even while REST is degraded.

IMPORTANT
---------
This is a public-data simulation. It is intentionally conservative and cannot
reproduce MEXC matching-engine priority perfectly. A future REAL version must
use private fee checks, openOrders/myTrades reconciliation and post-only order
handling before sending any live order.
"""

from __future__ import annotations

import argparse
import collections
import dataclasses
import datetime as dt
import hashlib
import json
import math
import os
import random
import signal
import statistics
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from decimal import Decimal, getcontext, ROUND_DOWN, ROUND_UP
from pathlib import Path
from typing import Any, Deque, Dict, Iterable, List, Optional, Tuple

getcontext().prec = 34

VERSION = "10.1.1"
BOT_NAME = "MEXC SPOT CROSS-QUOTE FLAT-INVENTORY DEMO V10.1.1"
BASE_URL = "https://api.mexc.com"
DEFAULT_STATE = "mexc_spot_crossquote_flat_inventory_demo_v10_1_1_state.json"

D0 = Decimal("0")
D1 = Decimal("1")
BPS = Decimal("10000")


def utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def utc_text(ts: Optional[float] = None) -> str:
    if ts is None:
        d = utc_now()
    else:
        d = dt.datetime.fromtimestamp(ts, tz=dt.timezone.utc)
    return d.strftime("%Y-%m-%d %H:%M:%S UTC")


def dec(x: Any, default: str = "0") -> Decimal:
    try:
        if isinstance(x, Decimal):
            return x
        return Decimal(str(x))
    except Exception:
        return Decimal(default)


def clamp(x: Decimal, lo: Decimal, hi: Decimal) -> Decimal:
    return max(lo, min(hi, x))


def q_down(x: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        return x
    return (x / step).to_integral_value(rounding=ROUND_DOWN) * step


def q_up(x: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        return x
    return (x / step).to_integral_value(rounding=ROUND_UP) * step


def fnum(x: Decimal | float, n: int = 4) -> str:
    return f"{float(x):,.{n}f}"


def pct(x: Decimal | float, n: int = 3) -> str:
    return f"{float(x):+.{n}f}%"


class APIDegraded(RuntimeError):
    pass


class PublicREST:
    """Serialized MEXC public REST client with global pacing/backoff."""

    def __init__(self, min_gap: float = 1.5, timeout: float = 8.0):
        self.min_gap = max(0.25, float(min_gap))
        self.timeout = float(timeout)
        self._lock = threading.Lock()
        self._last_request = 0.0
        self.degraded_until = 0.0
        self.backoff_level = 0
        self.waf_events = 0
        self.timeout_events = 0
        self.http_events = 0
        self.last_error = ""
        self.last_ok = time.time()
        self.resume_generation = 0
        self._was_degraded = False

    def is_degraded(self) -> bool:
        return time.time() < self.degraded_until

    def _enter_backoff(self, reason: str, timeout_event: bool = False) -> None:
        if timeout_event:
            self.timeout_events += 1
        else:
            self.waf_events += 1
        self.backoff_level = min(self.backoff_level + 1, 7)
        base = min(90.0, 2.0 ** self.backoff_level)
        wait = base + random.uniform(0.25, 1.25)
        self.degraded_until = max(self.degraded_until, time.time() + wait)
        self.last_error = reason
        self._was_degraded = True

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        with self._lock:
            now = time.monotonic()
            sleep_for = self.min_gap - (now - self._last_request)
            if sleep_for > 0:
                time.sleep(sleep_for)

            if self.is_degraded():
                raise APIDegraded(self.last_error or "API backoff")

            qs = urllib.parse.urlencode(params or {})
            url = f"{BASE_URL}{path}"
            if qs:
                url += "?" + qs
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": f"{BOT_NAME.replace(' ', '-')}/public-demo",
                    "Accept": "application/json",
                },
            )
            self._last_request = time.monotonic()
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    raw = r.read()
                    out = json.loads(raw.decode("utf-8"))
                self.last_ok = time.time()
                if self._was_degraded:
                    self._was_degraded = False
                    self.resume_generation += 1
                self.backoff_level = max(0, self.backoff_level - 1)
                return out
            except urllib.error.HTTPError as e:
                self.http_events += 1
                if e.code in (403, 418, 429):
                    self._enter_backoff(f"HTTP {e.code} {path}")
                    raise APIDegraded(self.last_error)
                self.last_error = f"HTTP {e.code} {path}"
                raise
            except (TimeoutError, urllib.error.URLError) as e:
                self._enter_backoff(f"TIMEOUT {path}: {e}", timeout_event=True)
                raise APIDegraded(self.last_error)


@dataclasses.dataclass
class Book:
    bid: Decimal
    bid_qty: Decimal
    ask: Decimal
    ask_qty: Decimal
    ts: float

    @property
    def mid(self) -> Decimal:
        if self.bid <= 0 or self.ask <= 0:
            return D0
        return (self.bid + self.ask) / 2


@dataclasses.dataclass
class SymbolMeta:
    symbol: str
    tick: Decimal = Decimal("0.00000001")
    step: Decimal = Decimal("0.00000001")
    min_qty: Decimal = D0
    min_notional: Decimal = D0


@dataclasses.dataclass
class VirtualOrder:
    oid: int
    symbol: str
    asset: str
    quote: str
    side: str
    level: int
    price: Decimal
    qty: Decimal
    remaining: Decimal
    created_ms: int
    eligible_ms: int
    queue_ahead: Decimal
    reserved_quote: Decimal = D0
    reserved_base: Decimal = D0
    fills: int = 0


@dataclasses.dataclass
class TradingLot:
    side: str
    qty: Decimal
    px_usdc: Decimal


@dataclasses.dataclass
class MarkoutPending:
    due_ts: float
    asset: str
    side: str
    qty: Decimal
    fill_px_usdc: Decimal
    fair_fill_usdc: Decimal


@dataclasses.dataclass
class AssetStats:
    asset: str
    sleeve_cap: Decimal
    active: bool = False
    initial_base: Decimal = D0
    base_qty: Decimal = D0
    fills_buy: int = 0
    fills_sell: int = 0
    fill_notional_usdc: Decimal = D0
    matched_notional_usdc: Decimal = D0
    cycles: int = 0
    maker_capture_usdc: Decimal = D0
    maker_fees_usdc: Decimal = D0
    realized_cycles_usdc: Decimal = D0
    markout_usdc: Decimal = D0
    markout_notional_usdc: Decimal = D0
    max_alpha_dd: Decimal = D0
    alpha_peak: Decimal = D0
    fair_hist: Deque[Tuple[float, Decimal]] = dataclasses.field(
        default_factory=lambda: collections.deque(maxlen=240)
    )
    trading_lots: Deque[TradingLot] = dataclasses.field(default_factory=collections.deque)

    def avg_markout_bps(self) -> Decimal:
        if self.markout_notional_usdc <= 0:
            return D0
        return self.markout_usdc / self.markout_notional_usdc * BPS


class Engine:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.state_path = Path(args.state).expanduser().resolve()
        self.rest = PublicREST(args.min_request_gap, args.timeout)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()

        self.capital = dec(args.capital)
        self.assets = [x.strip().upper() for x in args.assets.split(",") if x.strip()]
        self.max_active = min(max(1, args.max_active), len(self.assets))
        self.sleeve_cap = self.capital / Decimal(self.max_active)

        self.maker_fee_bps = dec(args.maker_fee_bps)
        self.taker_fee_bps = dec(args.taker_fee_bps)
        self.min_edge_bps = dec(args.min_edge_bps)
        self.full_edge_bps = dec(args.full_edge_bps)
        self.risk_buffer_bps = dec(args.risk_buffer_bps)
        self.participation = dec(args.participation)
        self.lot_fraction = dec(args.lot_fraction)

        self.inv_target = Decimal("0.025")
        self.inv_soft_lo = Decimal("0.015")
        self.inv_soft_hi = Decimal("0.035")
        self.inv_hard_lo = Decimal("0.005")
        self.inv_hard_hi = Decimal("0.050")

        self.books: Dict[str, Book] = {}
        self.meta: Dict[str, SymbolMeta] = {}
        self.depth_cache: Dict[str, Tuple[float, Dict[str, Dict[Decimal, Decimal]]]] = {}
        self.orders: Dict[Tuple[str, str, int], VirtualOrder] = {}
        self.next_oid = 1
        self.tape_cursor_ms: Dict[str, int] = {}
        self.tape_rr: Deque[str] = collections.deque()
        self.depth_rr: Deque[str] = collections.deque()
        self.pending_markouts: List[MarkoutPending] = []
        self.stats: Dict[str, AssetStats] = {
            a: AssetStats(a, self.sleeve_cap) for a in self.assets
        }

        self.cash_usdc = self.capital
        self.cash_usdt = D0
        self.initial_cash_usdc = self.capital
        self.initial_cash_usdt = D0
        self.initial_base: Dict[str, Decimal] = {a: D0 for a in self.assets}

        self.bootstrap_quote_conversion_fee = D0
        self.bootstrap_seed_fee = D0
        self.bootstrap_cost = D0
        self.seed_equity0 = self.capital
        self.start_ts = time.time()
        self.ready_ts = 0.0
        self.last_book_fetch = 0.0
        self.last_quote_refresh = 0.0
        self.last_tape_poll = 0.0
        self.last_depth_poll = 0.0
        self.last_save = 0.0
        self.last_status_ts = 0.0
        self.last_report_ts = 0.0
        self.last_resume_generation = 0
        self.api_resume_count = 0
        self.tape_saturated = 0
        self.quote_created = 0
        self.quote_repriced = 0
        self.quote_preserved = 0
        self.quote_cancelled = 0
        self.no_fill_blackouts = 0
        self.log_lines = 0

    # ---------- API / market data ----------

    def fetch_exchange_info(self) -> None:
        try:
            data = self.rest.get("/api/v3/exchangeInfo")
        except Exception as e:
            print(f"{utc_text()} | WARN | exchangeInfo non disponibile: {e}")
            return
        wanted = {"USDCUSDT"}
        for a in self.assets:
            wanted.add(f"{a}USDC")
            wanted.add(f"{a}USDT")
        for s in data.get("symbols", []):
            sym = str(s.get("symbol", "")).upper()
            if sym not in wanted:
                continue
            m = SymbolMeta(sym)
            for f in s.get("filters", []):
                ft = f.get("filterType")
                if ft == "PRICE_FILTER":
                    m.tick = dec(f.get("tickSize"), "0.00000001")
                elif ft == "LOT_SIZE":
                    m.step = dec(f.get("stepSize"), "0.00000001")
                    m.min_qty = dec(f.get("minQty"))
                elif ft in ("MIN_NOTIONAL", "NOTIONAL"):
                    m.min_notional = dec(f.get("minNotional", f.get("notional", "0")))
            self.meta[sym] = m

    def fetch_all_books(self) -> bool:
        try:
            data = self.rest.get("/api/v3/ticker/bookTicker")
        except APIDegraded:
            return False
        except Exception as e:
            print(f"{utc_text()} | WARN | bookTicker: {e}")
            return False
        now = time.time()
        if isinstance(data, dict):
            data = [data]
        wanted = {"USDCUSDT"}
        for a in self.assets:
            wanted.add(f"{a}USDC")
            wanted.add(f"{a}USDT")
        for row in data:
            sym = str(row.get("symbol", "")).upper()
            if sym not in wanted:
                continue
            bid = dec(row.get("bidPrice"))
            ask = dec(row.get("askPrice"))
            if bid <= 0 or ask <= 0 or ask < bid:
                continue
            self.books[sym] = Book(
                bid=bid,
                bid_qty=dec(row.get("bidQty")),
                ask=ask,
                ask_qty=dec(row.get("askQty")),
                ts=now,
            )
        self.last_book_fetch = now
        return "USDCUSDT" in self.books

    def get_cached_depth(self, symbol: str) -> Optional[Dict[str, Dict[Decimal, Decimal]]]:
        cached = self.depth_cache.get(symbol)
        if not cached:
            return None
        if time.time() - cached[0] > self.args.depth_ttl:
            return None
        return cached[1]

    def refresh_one_depth(self) -> None:
        """Refresh at most ONE symbol per scheduler turn; never bursts /depth."""
        if self.rest.is_degraded() or not self.depth_rr:
            return
        symbol = self.depth_rr[0]
        self.depth_rr.rotate(-1)
        cached = self.depth_cache.get(symbol)
        if cached and time.time() - cached[0] <= self.args.depth_ttl:
            return
        try:
            data = self.rest.get("/api/v3/depth", {"symbol": symbol, "limit": 20})
        except APIDegraded:
            return
        except Exception:
            return
        out = {
            "BUY": {dec(p): dec(q) for p, q in data.get("bids", [])},
            "SELL": {dec(p): dec(q) for p, q in data.get("asks", [])},
        }
        self.depth_cache[symbol] = (time.time(), out)
        self.last_depth_poll = time.time()

    def queue_ahead_for(self, symbol: str, side: str, price: Decimal) -> Decimal:
        # IMPORTANT: quote construction never calls REST. It uses the most recent
        # cached depth; if unavailable, it falls back conservatively to 1.5x top qty.
        d = self.get_cached_depth(symbol)
        if d:
            levels = d[side]
            if price in levels:
                return levels[price]
        b = self.books.get(symbol)
        if not b:
            return D0
        top = b.bid_qty if side == "BUY" else b.ask_qty
        return max(D0, top * Decimal("1.5"))

    # ---------- prices / fair ----------

    def usdt_to_usdc(self, usdt: Decimal) -> Decimal:
        fx = self.books.get("USDCUSDT")
        if not fx or fx.ask <= 0:
            return usdt
        return usdt / fx.ask

    def usdc_to_usdt(self, usdc: Decimal) -> Decimal:
        fx = self.books.get("USDCUSDT")
        if not fx or fx.bid <= 0:
            return usdc
        return usdc * fx.bid

    def pair_px_usdc(self, symbol: str, px: Decimal) -> Decimal:
        if symbol.endswith("USDC"):
            return px
        fx = self.books.get("USDCUSDT")
        if not fx or fx.mid <= 0:
            return px
        return px / fx.mid

    def fair_usdc(self, asset: str) -> Optional[Decimal]:
        p1 = self.books.get(f"{asset}USDC")
        p2 = self.books.get(f"{asset}USDT")
        fx = self.books.get("USDCUSDT")
        vals: List[Decimal] = []
        if p1 and p1.mid > 0:
            vals.append(p1.mid)
        if p2 and fx and p2.mid > 0 and fx.mid > 0:
            vals.append(p2.mid / fx.mid)
        if not vals:
            return None
        vals.sort()
        return vals[len(vals) // 2] if len(vals) % 2 else sum(vals) / Decimal(len(vals))

    def synthetic_fair_for_symbol(self, asset: str, symbol: str) -> Optional[Decimal]:
        fx = self.books.get("USDCUSDT")
        u = self.books.get(f"{asset}USDC")
        t = self.books.get(f"{asset}USDT")
        if symbol.endswith("USDC"):
            if t and fx and t.mid > 0 and fx.mid > 0:
                return t.mid / fx.mid
            return u.mid if u else None
        if u and fx and u.mid > 0 and fx.mid > 0:
            return u.mid * fx.mid
        return t.mid if t else None

    def liquidation_base_value(self, asset: str, qty: Decimal) -> Decimal:
        if qty <= 0:
            return D0
        candidates: List[Decimal] = []
        u = self.books.get(f"{asset}USDC")
        t = self.books.get(f"{asset}USDT")
        fx = self.books.get("USDCUSDT")
        if u and u.bid > 0:
            candidates.append(qty * u.bid)
        if t and fx and t.bid > 0 and fx.ask > 0:
            candidates.append(qty * t.bid / fx.ask)
        return max(candidates) if candidates else D0

    # ---------- accounting ----------

    def equity(self) -> Decimal:
        v = self.cash_usdc + self.usdt_to_usdc(self.cash_usdt)
        for a, st in self.stats.items():
            v += self.liquidation_base_value(a, st.base_qty)
        return v

    def benchmark_equity(self) -> Decimal:
        v = self.initial_cash_usdc + self.usdt_to_usdc(self.initial_cash_usdt)
        for a, q in self.initial_base.items():
            v += self.liquidation_base_value(a, q)
        return v

    def alpha(self) -> Decimal:
        return self.equity() - self.benchmark_equity()

    def total_maker_capture(self) -> Decimal:
        return sum((s.maker_capture_usdc for s in self.stats.values()), D0)

    def total_realized_cycles(self) -> Decimal:
        return sum((s.realized_cycles_usdc for s in self.stats.values()), D0)

    def total_maker_fees(self) -> Decimal:
        return sum((s.maker_fees_usdc for s in self.stats.values()), D0)

    def total_markout(self) -> Decimal:
        return sum((s.markout_usdc for s in self.stats.values()), D0)

    def total_matched(self) -> Decimal:
        return sum((s.matched_notional_usdc for s in self.stats.values()), D0)

    def total_cycles(self) -> int:
        return sum(s.cycles for s in self.stats.values())

    def base_inventory_value(self) -> Decimal:
        return sum((self.liquidation_base_value(a, s.base_qty) for a, s in self.stats.items()), D0)

    def live_notional(self) -> Tuple[Decimal, Decimal, Decimal]:
        buy = D0
        sell = D0
        for o in self.orders.values():
            if o.remaining <= 0:
                continue
            n = self.pair_px_usdc(o.symbol, o.price) * o.remaining
            if o.side == "BUY":
                buy += n
            else:
                sell += n
        return buy, sell, buy + sell

    def economic_engaged(self) -> Decimal:
        buy, _, _ = self.live_notional()
        return self.base_inventory_value() + buy

    # ---------- initialization ----------

    def select_active_assets(self) -> List[str]:
        scored: List[Tuple[Decimal, str]] = []
        for a in self.assets:
            best = Decimal("-999")
            for sym in (f"{a}USDC", f"{a}USDT"):
                b = self.books.get(sym)
                fair = self.synthetic_fair_for_symbol(a, sym)
                if not b or not fair or fair <= 0:
                    continue
                buy_edge = (fair - b.bid) / fair * BPS
                sell_edge = (b.ask - fair) / fair * BPS
                best = max(best, buy_edge, sell_edge)
            scored.append((best, a))
        scored.sort(reverse=True)
        return [a for _, a in scored[: self.max_active]]

    def bootstrap_quote_currencies(self) -> None:
        """Convert 50% USDC to USDT once, explicitly charging taker fee."""
        fx = self.books.get("USDCUSDT")
        if not fx or fx.bid <= 0:
            return
        convert_usdc = self.capital * Decimal("0.50")
        fee_usdc = convert_usdc * self.taker_fee_bps / BPS
        spend = convert_usdc
        received_usdt = (spend - fee_usdc) * fx.bid
        self.cash_usdc -= spend
        self.cash_usdt += received_usdt
        self.bootstrap_quote_conversion_fee += fee_usdc

    def seed_asset(self, asset: str) -> None:
        st = self.stats[asset]
        target_value = st.sleeve_cap * self.inv_target
        u = self.books.get(f"{asset}USDC")
        t = self.books.get(f"{asset}USDT")
        fx = self.books.get("USDCUSDT")
        choices: List[Tuple[Decimal, str, Decimal]] = []
        if u and u.ask > 0:
            choices.append((u.ask, "USDC", u.ask))
        if t and fx and t.ask > 0 and fx.mid > 0:
            choices.append((t.ask / fx.mid, "USDT", t.ask))
        if not choices:
            return
        choices.sort(key=lambda z: z[0])
        _, quote, exec_px = choices[0]
        fee_usdc = target_value * self.taker_fee_bps / BPS
        spend_usdc = target_value + fee_usdc
        if quote == "USDC":
            if self.cash_usdc < spend_usdc:
                return
            qty = target_value / exec_px
            self.cash_usdc -= spend_usdc
        else:
            if not fx or fx.mid <= 0:
                return
            target_usdt = target_value * fx.mid
            fee_usdt = target_usdt * self.taker_fee_bps / BPS
            if self.cash_usdt < target_usdt + fee_usdt:
                return
            qty = target_usdt / exec_px
            self.cash_usdt -= target_usdt + fee_usdt
        st.base_qty += qty
        st.initial_base = qty
        self.initial_base[asset] = qty
        self.bootstrap_seed_fee += fee_usdc
        print(
            f"{utc_text()} | INFO | [SEED {asset}] base_share=2.50% "
            f"taker_fee_usdc={fnum(fee_usdc, 6)}"
        )

    def initialize(self) -> None:
        print(f"{utc_text()} | INFO | [INIT] caricamento metadata e book pubblici...")
        self.fetch_exchange_info()
        while not self.stop_event.is_set():
            if self.fetch_all_books():
                break
            time.sleep(1.0)
        if self.stop_event.is_set():
            return

        active = self.select_active_assets()
        for a in active:
            self.stats[a].active = True

        self.bootstrap_quote_currencies()
        for a in active:
            self.seed_asset(a)

        # Freeze the passive benchmark AFTER the exact same bootstrap.
        self.initial_cash_usdc = self.cash_usdc
        self.initial_cash_usdt = self.cash_usdt
        for a in self.assets:
            self.initial_base[a] = self.stats[a].base_qty

        self.seed_equity0 = self.equity()
        self.bootstrap_cost = self.capital - self.seed_equity0
        self.ready_ts = time.time()
        self.start_ts = self.ready_ts
        self.last_resume_generation = self.rest.resume_generation

        print(f"{utc_text()} | INFO | [INIT COMPLETE] active={','.join(active)}")
        print(
            f"{utc_text()} | INFO | [BOOTSTRAP] costo_mark_to_market={fnum(self.bootstrap_cost, 6)} "
            f"fee_quote={fnum(self.bootstrap_quote_conversion_fee, 6)} "
            f"fee_seed={fnum(self.bootstrap_seed_fee, 6)} alpha={fnum(self.alpha(), 6)}"
        )

    # ---------- opportunity / order creation ----------

    def update_fair_history(self) -> None:
        now = time.time()
        for a, st in self.stats.items():
            if not st.active:
                continue
            f = self.fair_usdc(a)
            if f and f > 0:
                st.fair_hist.append((now, f))

    def fair_momentum_30_bps(self, asset: str) -> Decimal:
        st = self.stats[asset]
        if len(st.fair_hist) < 2:
            return D0
        now = st.fair_hist[-1][0]
        current = st.fair_hist[-1][1]
        ref = st.fair_hist[0][1]
        for ts, px in reversed(st.fair_hist):
            if now - ts >= 30:
                ref = px
                break
        if ref <= 0:
            return D0
        return (current / ref - 1) * BPS

    def adverse_penalty_bps(self, asset: str, side: str) -> Decimal:
        st = self.stats[asset]
        mom = self.fair_momentum_30_bps(asset)
        directional = D0
        if side == "BUY" and mom < 0:
            directional = -mom * Decimal("0.35")
        elif side == "SELL" and mom > 0:
            directional = mom * Decimal("0.35")
        ex_post = max(D0, -st.avg_markout_bps()) * Decimal("0.50")
        return min(Decimal("5"), directional + ex_post)

    def base_share(self, asset: str) -> Decimal:
        st = self.stats[asset]
        if st.sleeve_cap <= 0:
            return D0
        return self.liquidation_base_value(asset, st.base_qty) / st.sleeve_cap

    def side_allowed(self, asset: str, side: str) -> bool:
        sh = self.base_share(asset)
        if side == "BUY":
            return sh < self.inv_hard_hi
        return sh > self.inv_hard_lo

    def desired_orders(self) -> List[VirtualOrder]:
        out: List[VirtualOrder] = []
        now_ms = int(time.time() * 1000)
        multipliers = [Decimal("1.0"), Decimal("1.5"), Decimal("2.0")]

        # Recompute reservations from the DESIRED book exactly once. Existing
        # preserved orders are included during this pass, so they are not double-counted.
        reserved_buy_usdc = D0
        reserved_buy_usdt = D0
        reserved_sell: Dict[str, Decimal] = collections.defaultdict(Decimal)

        for asset, st in self.stats.items():
            if not st.active:
                continue
            share = self.base_share(asset)
            base_value = self.liquidation_base_value(asset, st.base_qty)
            hard_max_val = st.sleeve_cap * self.inv_hard_hi
            hard_min_val = st.sleeve_cap * self.inv_hard_lo
            buy_capacity_usdc = max(D0, hard_max_val - base_value)
            sell_capacity_usdc = max(D0, base_value - hard_min_val)

            # Soft inventory band changes aggressiveness, not a global ON/OFF switch.
            buy_scale = Decimal("1")
            sell_scale = Decimal("1")
            if share >= self.inv_soft_hi:
                buy_scale = Decimal("0.25")
                sell_scale = Decimal("1.25")
            elif share <= self.inv_soft_lo:
                buy_scale = Decimal("1.25")
                sell_scale = Decimal("0.25")

            for symbol in (f"{asset}USDC", f"{asset}USDT"):
                b = self.books.get(symbol)
                fair = self.synthetic_fair_for_symbol(asset, symbol)
                if not b or not fair or fair <= 0:
                    continue
                meta = self.meta.get(symbol, SymbolMeta(symbol))
                tick = meta.tick if meta.tick > 0 else max(Decimal("0.00000001"), b.ask - b.bid)
                quote = "USDC" if symbol.endswith("USDC") else "USDT"

                for side in ("BUY", "SELL"):
                    if not self.side_allowed(asset, side):
                        continue
                    adverse = self.adverse_penalty_bps(asset, side)
                    for level, mult in enumerate(multipliers, start=1):
                        if side == "BUY":
                            px = b.bid - tick * Decimal(level - 1)
                            raw_edge = (fair - px) / fair * BPS
                            scale = buy_scale
                        else:
                            px = b.ask + tick * Decimal(level - 1)
                            raw_edge = (px - fair) / fair * BPS
                            scale = sell_scale
                        net_edge = raw_edge - self.maker_fee_bps - self.risk_buffer_bps - adverse
                        required = self.min_edge_bps if level == 1 else self.full_edge_bps
                        if net_edge < required:
                            continue

                        lot_usdc = st.sleeve_cap * self.lot_fraction * mult * scale
                        if side == "BUY":
                            lot_usdc = min(lot_usdc, buy_capacity_usdc)
                        else:
                            lot_usdc = min(lot_usdc, sell_capacity_usdc)
                        if lot_usdc <= 0:
                            continue

                        px_usdc = self.pair_px_usdc(symbol, px)
                        if px_usdc <= 0:
                            continue
                        qty = q_down(lot_usdc / px_usdc, meta.step)
                        if qty <= 0 or (meta.min_qty > 0 and qty < meta.min_qty):
                            continue

                        # Spot balance reservations.
                        if side == "BUY":
                            need_quote = px * qty
                            if quote == "USDC":
                                avail = self.cash_usdc - reserved_buy_usdc
                                if need_quote > avail:
                                    qty = q_down(max(D0, avail) / px, meta.step)
                                reserved_buy_usdc += px * max(D0, qty)
                            else:
                                avail = self.cash_usdt - reserved_buy_usdt
                                if need_quote > avail:
                                    qty = q_down(max(D0, avail) / px, meta.step)
                                reserved_buy_usdt += px * max(D0, qty)
                        else:
                            avail_base = st.base_qty - reserved_sell[asset]
                            if qty > avail_base:
                                qty = q_down(max(D0, avail_base), meta.step)
                            reserved_sell[asset] += max(D0, qty)

                        if qty <= 0:
                            continue
                        notional_quote = px * qty
                        if meta.min_notional > 0 and notional_quote < meta.min_notional:
                            continue

                        key = (symbol, side, level)
                        old = self.orders.get(key)
                        if old and old.price == px and old.remaining > 0:
                            self.quote_preserved += 1
                            out.append(old)
                            continue

                        q_ahead = self.queue_ahead_for(symbol, side, px)
                        out.append(
                            VirtualOrder(
                                oid=self.next_oid,
                                symbol=symbol,
                                asset=asset,
                                quote=quote,
                                side=side,
                                level=level,
                                price=px,
                                qty=qty,
                                remaining=qty,
                                created_ms=now_ms,
                                eligible_ms=now_ms + int(self.args.min_life * 1000),
                                queue_ahead=q_ahead,
                            )
                        )
                        self.next_oid += 1
        return out

    def refresh_quotes(self) -> None:
        if self.rest.is_degraded():
            return
        desired = self.desired_orders()
        desired_map = {(o.symbol, o.side, o.level): o for o in desired}
        now_ms = int(time.time() * 1000)
        new_orders: Dict[Tuple[str, str, int], VirtualOrder] = {}

        for key, want in desired_map.items():
            old = self.orders.get(key)
            if old and old.remaining > 0 and old.price == want.price:
                new_orders[key] = old
                continue
            if old and old.remaining > 0 and now_ms - old.created_ms < int(self.args.min_life * 1000):
                new_orders[key] = old
                continue
            if old and old.remaining > 0:
                self.quote_repriced += 1
            else:
                self.quote_created += 1
            new_orders[key] = want

        for key, old in self.orders.items():
            if key in new_orders or old.remaining <= 0:
                continue
            if now_ms - old.created_ms < int(self.args.min_life * 1000):
                new_orders[key] = old
            else:
                self.quote_cancelled += 1

        self.orders = new_orders
        syms = sorted({o.symbol for o in self.orders.values() if o.remaining > 0})
        self.tape_rr = collections.deque(syms)
        self.depth_rr = collections.deque(syms)
        for s in syms:
            self.tape_cursor_ms.setdefault(s, now_ms)
        self.last_quote_refresh = time.time()

    # ---------- tape / fills ----------

    def handle_resume_if_needed(self) -> None:
        if self.rest.resume_generation == self.last_resume_generation:
            return
        self.last_resume_generation = self.rest.resume_generation
        self.api_resume_count += 1
        now_ms = int(time.time() * 1000)
        # No retro-fill: skip the blackout completely and preserve order identity/price.
        for sym in list(self.tape_cursor_ms):
            self.tape_cursor_ms[sym] = now_ms
        for o in self.orders.values():
            o.eligible_ms = max(o.eligible_ms, now_ms + int(self.args.min_life * 1000))
        self.no_fill_blackouts += 1
        print(
            f"{utc_text()} | INFO | [API RESUME] virtual orders PRESERVED; "
            f"tape cursors re-primed; no retro-fill"
        )

    def poll_one_tape(self) -> None:
        if self.rest.is_degraded() or not self.tape_rr:
            return
        symbol = self.tape_rr[0]
        self.tape_rr.rotate(-1)
        now_ms = int(time.time() * 1000)
        start_ms = self.tape_cursor_ms.get(symbol, now_ms)
        if now_ms <= start_ms:
            return
        params = {
            "symbol": symbol,
            "startTime": start_ms + 1,
            "endTime": now_ms,
            "limit": 1000,
        }
        try:
            trades = self.rest.get("/api/v3/aggTrades", params)
        except APIDegraded:
            return
        except Exception:
            return
        if not isinstance(trades, list):
            self.tape_cursor_ms[symbol] = now_ms
            return
        if len(trades) >= 1000:
            # Busy window cannot be reconstructed safely with this REST sample.
            self.tape_saturated += 1
            self.tape_cursor_ms[symbol] = now_ms
            return
        for tr in trades:
            self.apply_trade(symbol, tr)
        self.tape_cursor_ms[symbol] = now_ms
        self.last_tape_poll = time.time()

    def apply_trade(self, symbol: str, tr: Dict[str, Any]) -> None:
        t_ms = int(tr.get("T") or tr.get("time") or 0)
        px = dec(tr.get("p") or tr.get("price"))
        qty = dec(tr.get("q") or tr.get("qty"))
        buyer_is_maker = bool(tr.get("m", False))
        if t_ms <= 0 or px <= 0 or qty <= 0:
            return

        for key, o in list(self.orders.items()):
            if o.symbol != symbol or o.remaining <= 0 or t_ms < o.eligible_ms:
                continue
            directional = False
            if o.side == "BUY":
                directional = buyer_is_maker and px <= o.price
            else:
                directional = (not buyer_is_maker) and px >= o.price
            if not directional:
                continue

            available = qty
            if o.queue_ahead > 0:
                consumed = min(o.queue_ahead, available)
                o.queue_ahead -= consumed
                available -= consumed
            if available <= 0:
                continue

            fill_qty = min(o.remaining, available * self.participation)
            if fill_qty <= 0:
                continue
            self.execute_virtual_fill(o, fill_qty, t_ms)
            if o.remaining <= 0:
                self.orders.pop(key, None)

    def execute_virtual_fill(self, o: VirtualOrder, qty: Decimal, t_ms: int) -> None:
        st = self.stats[o.asset]
        quote_notional = o.price * qty
        px_usdc = self.pair_px_usdc(o.symbol, o.price)
        notional_usdc = px_usdc * qty
        fee_quote = quote_notional * self.maker_fee_bps / BPS
        fee_usdc = (
            fee_quote if o.quote == "USDC" else self.usdt_to_usdc(fee_quote)
        )

        if o.side == "BUY":
            total = quote_notional + fee_quote
            if o.quote == "USDC":
                if total > self.cash_usdc:
                    return
                self.cash_usdc -= total
            else:
                if total > self.cash_usdt:
                    return
                self.cash_usdt -= total
            st.base_qty += qty
            st.fills_buy += 1
        else:
            if qty > st.base_qty:
                qty = st.base_qty
                quote_notional = o.price * qty
                notional_usdc = px_usdc * qty
                fee_quote = quote_notional * self.maker_fee_bps / BPS
                fee_usdc = fee_quote if o.quote == "USDC" else self.usdt_to_usdc(fee_quote)
            if qty <= 0:
                return
            st.base_qty -= qty
            proceeds = quote_notional - fee_quote
            if o.quote == "USDC":
                self.cash_usdc += proceeds
            else:
                self.cash_usdt += proceeds
            st.fills_sell += 1

        o.remaining -= qty
        o.fills += 1
        st.fill_notional_usdc += notional_usdc
        st.maker_fees_usdc += fee_usdc

        fair_pair = self.synthetic_fair_for_symbol(o.asset, o.symbol)
        fair_usdc = self.fair_usdc(o.asset) or px_usdc
        if fair_pair and fair_pair > 0:
            if o.side == "BUY":
                gross_bps = (fair_pair - o.price) / fair_pair * BPS
            else:
                gross_bps = (o.price - fair_pair) / fair_pair * BPS
            capture = notional_usdc * (gross_bps - self.maker_fee_bps) / BPS
            st.maker_capture_usdc += capture

        self.match_trading_lots(st, o.side, qty, px_usdc, fee_usdc)
        self.pending_markouts.append(
            MarkoutPending(
                due_ts=time.time() + 30.0,
                asset=o.asset,
                side=o.side,
                qty=qty,
                fill_px_usdc=px_usdc,
                fair_fill_usdc=fair_usdc,
            )
        )

    def match_trading_lots(
        self, st: AssetStats, side: str, qty: Decimal, px_usdc: Decimal, fee_usdc: Decimal
    ) -> None:
        remaining = qty
        matched_qty = D0
        realized = D0
        while remaining > 0 and st.trading_lots and st.trading_lots[0].side != side:
            lot = st.trading_lots[0]
            m = min(remaining, lot.qty)
            if side == "SELL":
                pnl = (px_usdc - lot.px_usdc) * m
            else:
                pnl = (lot.px_usdc - px_usdc) * m
            realized += pnl
            matched_qty += m
            remaining -= m
            lot.qty -= m
            if lot.qty <= 0:
                st.trading_lots.popleft()
        if remaining > 0:
            st.trading_lots.append(TradingLot(side, remaining, px_usdc))
        if matched_qty > 0:
            st.realized_cycles_usdc += realized - fee_usdc * (matched_qty / max(qty, Decimal("1e-30")))
            st.matched_notional_usdc += px_usdc * matched_qty * 2
            st.cycles += 1

    def process_markouts(self) -> None:
        now = time.time()
        keep: List[MarkoutPending] = []
        for p in self.pending_markouts:
            if p.due_ts > now:
                keep.append(p)
                continue
            f = self.fair_usdc(p.asset)
            if not f or f <= 0 or p.fill_px_usdc <= 0:
                continue
            if p.side == "BUY":
                bps = (f - p.fill_px_usdc) / p.fill_px_usdc * BPS
            else:
                bps = (p.fill_px_usdc - f) / p.fill_px_usdc * BPS
            n = p.fill_px_usdc * p.qty
            st = self.stats[p.asset]
            st.markout_usdc += n * bps / BPS
            st.markout_notional_usdc += n
        self.pending_markouts = keep

    # ---------- reporting ----------

    def update_drawdown(self) -> None:
        a = self.alpha()
        active = [s for s in self.stats.values() if s.active]
        if not active:
            return
        # Portfolio alpha DD copied to each active sleeve only as a conservative headline.
        peak = max([s.alpha_peak for s in active] + [a])
        dd = a - peak
        for s in active:
            s.alpha_peak = max(s.alpha_peak, a)
            s.max_alpha_dd = min(s.max_alpha_dd, dd)

    def projection_label(self, elapsed_h: float) -> str:
        if elapsed_h < 1:
            return "N/D — WARMUP <1h"
        if elapsed_h < 6:
            return "MOLTO PROVVISORIA 1-6h"
        if elapsed_h < 24:
            return "PROVVISORIA 6-24h"
        if elapsed_h < 72:
            return "BASE 24H+"
        return "BASE 72H+"

    def monthly_projection(self, value: Decimal, elapsed_h: float) -> Optional[Decimal]:
        if elapsed_h < 1:
            return None
        return value / dec(elapsed_h) * Decimal("24") * Decimal("30")

    def status_line(self) -> str:
        eq = self.equity()
        a = self.alpha()
        buy, sell, live = self.live_notional()
        engaged = self.economic_engaged()
        api = "DEGRADED" if self.rest.is_degraded() else "OK"
        return (
            f"{utc_text()} | STATUS | EQ={fnum(eq,4)} ALPHA={fnum(a,4)} "
            f"LIVE={fnum(live,2)} IMPEGNATO={fnum(engaged,2)} "
            f"MATCH={fnum(self.total_matched(),2)} CICLI={self.total_cycles()} "
            f"API={api} 403/429={self.rest.waf_events} timeout={self.rest.timeout_events}"
        )

    def report(self) -> str:
        with self.lock:
            self.update_drawdown()
            now = time.time()
            elapsed_h = max((now - self.start_ts) / 3600.0, 1e-9)
            eq = self.equity()
            bench = self.benchmark_equity()
            pnl_true = eq - self.capital
            trading_pnl = eq - self.seed_equity0
            a = eq - bench
            maker = self.total_maker_capture()
            closed = self.total_realized_cycles()
            fees = self.total_maker_fees()
            markout = self.total_markout()
            inv = self.base_inventory_value()
            buy_live, sell_live, live = self.live_notional()
            engaged = self.economic_engaged()
            proj_a = self.monthly_projection(a, elapsed_h)
            proj_tr = self.monthly_projection(trading_pnl, elapsed_h)
            label = self.projection_label(elapsed_h)

            lines = []
            lines.append("\n" + "=" * 150)
            lines.append(f"{BOT_NAME} | {utc_text()} | NESSUN ORDINE REALE")
            lines.append("=" * 150)
            lines.append("RISULTATO PRINCIPALE — contabilità separata tra bootstrap e trading")
            lines.append(f"  Capitale virtuale iniziale                 : {fnum(self.capital,2)} USDC")
            lines.append(f"  Patrimonio liquidabile ORA                 : {fnum(eq,6)} USDC")
            lines.append(f"  PNL VERO vs capitale iniziale               : {fnum(pnl_true,6)} USDC")
            lines.append(f"  Costo bootstrap mark-to-market              : {fnum(self.bootstrap_cost,6)} USDC")
            lines.append(f"    fee conversione USDC->USDT                : {fnum(self.bootstrap_quote_conversion_fee,6)} USDC")
            lines.append(f"    fee seed asset                             : {fnum(self.bootstrap_seed_fee,6)} USDC")
            lines.append(f"  PNL TRADING dopo bootstrap                  : {fnum(trading_pnl,6)} USDC")
            lines.append(f"  Benchmark passivo stessa seed               : {fnum(bench,6)} USDC")
            lines.append(f"  ALPHA vs benchmark                          : {fnum(a,6)} USDC")
            lines.append(f"  Maker capture teorico su fill               : {fnum(maker,6)} USDC")
            lines.append(f"  Cicli matched realizzati                    : {fnum(closed,6)} USDC | cicli {self.total_cycles()}")
            lines.append(f"  Markout 30s cumulativo                      : {fnum(markout,6)} USDC")
            lines.append(f"  Fee maker simulate                          : {fnum(fees,6)} USDC")
            lines.append("-" * 150)
            lines.append("CAPITALE — NON confonde assegnato con realmente impegnato")
            lines.append(f"  Capitale sleeve assegnato                   : {fnum(self.sleeve_cap*self.max_active,2)} USDC | {self.max_active} asset ACTIVE")
            lines.append(f"  Inventory volatile mark-to-market           : {fnum(inv,2)} USDC | {float(inv/self.capital*100):.2f}% del capitale")
            lines.append(f"  Ordini BUY vivi / SELL vivi                 : {fnum(buy_live,2)} / {fnum(sell_live,2)} USDC")
            lines.append(f"  Notional ordini vivi totale                 : {fnum(live,2)} USDC")
            lines.append(f"  Capitale economicamente impegnato           : {fnum(engaged,2)} USDC | {float(engaged/self.capital*100):.2f}%")
            lines.append(f"  Volume matched cicli                        : {fnum(self.total_matched(),2)} USDC")
            lines.append("-" * 150)
            lines.append("PROIEZIONI")
            if proj_tr is None:
                lines.append(f"  PNL trading / mese                          : N/D | {label}")
                lines.append(f"  ALPHA / mese                                : N/D | {label}")
            else:
                lines.append(f"  PNL trading / mese                          : {fnum(proj_tr,2)} USDC | {float(proj_tr/self.capital*100):+.3f}% | {label}")
                lines.append(f"  ALPHA / mese                                : {fnum(proj_a or D0,2)} USDC | {float((proj_a or D0)/self.capital*100):+.3f}% | {label}")
            lines.append("-" * 150)
            lines.append("DETTAGLIO ASSET")
            lines.append(
                "ASSET  STATO     CAP       BASE%    FILLS B/S   MATCHED     CICLI   CAPTURE    CLOSED    MARKOUT   MKOUTbp   MOM30   LIVE"
            )
            for asset in self.assets:
                st = self.stats[asset]
                if not st.active:
                    lines.append(f"{asset:<6} RESERVE   {fnum(st.sleeve_cap,0):>7}       -          -          -         -         -         -         -        -       -      -")
                    continue
                base_pct = self.base_share(asset) * Decimal("100")
                mkbps = st.avg_markout_bps()
                mom = self.fair_momentum_30_bps(asset)
                live_asset = sum(
                    (self.pair_px_usdc(o.symbol, o.price) * o.remaining for o in self.orders.values() if o.asset == asset),
                    D0,
                )
                lines.append(
                    f"{asset:<6} ACTIVE    {fnum(st.sleeve_cap,0):>7}  {float(base_pct):7.3f}%  "
                    f"{st.fills_buy:4d}/{st.fills_sell:<4d} {fnum(st.matched_notional_usdc,2):>10}  {st.cycles:7d} "
                    f"{fnum(st.maker_capture_usdc,4):>9} {fnum(st.realized_cycles_usdc,4):>9} "
                    f"{fnum(st.markout_usdc,4):>9} {float(mkbps):8.3f} {float(mom):7.3f} {fnum(live_asset,2):>8}"
                )
            lines.append("-" * 150)
            api_state = "DEGRADED" if self.rest.is_degraded() else "OK"
            lines.append("INFRASTRUTTURA / CODA")
            lines.append(f"  API state                                   : {api_state}")
            lines.append(f"  WAF/rate-limit / timeout                    : {self.rest.waf_events} / {self.rest.timeout_events}")
            lines.append(f"  API resume conservativi                     : {self.api_resume_count} | blackout senza retro-fill {self.no_fill_blackouts}")
            lines.append(f"  Tape saturo >=1000                          : {self.tape_saturated}")
            lines.append(f"  Quote create/reprice/preserve/cancel        : {self.quote_created}/{self.quote_repriced}/{self.quote_preserved}/{self.quote_cancelled}")
            lines.append(f"  Participation massima                       : {float(self.participation*100):.1f}% | min life {self.args.min_life:.0f}s")
            lines.append("-" * 150)
            lines.append("REGOLE CHIAVE")
            lines.append("  Futures/leva                                : ASSENTI")
            lines.append(f"  Inventory target/soft/hard                  : 2.5% | 1.5-3.5% | 0.5-5.0% per sleeve")
            lines.append(f"  Edge netto minimo/full                      : {self.min_edge_bps} / {self.full_edge_bps} bp")
            lines.append(f"  Fee simulate maker/taker                    : {self.maker_fee_bps} / {self.taker_fee_bps} bp")
            lines.append(f"  REST gap / depth TTL / refresh                : {self.args.min_request_gap:.2f}s / {self.args.depth_ttl:.0f}s / {self.args.depth_refresh:.0f}s")
            lines.append("=" * 150)
            return "\n".join(lines)

    # ---------- persistence ----------

    def save_state(self) -> None:
        with self.lock:
            state = {
                "version": VERSION,
                "saved_at": utc_text(),
                "capital": str(self.capital),
                "cash_usdc": str(self.cash_usdc),
                "cash_usdt": str(self.cash_usdt),
                "initial_cash_usdc": str(self.initial_cash_usdc),
                "initial_cash_usdt": str(self.initial_cash_usdt),
                "initial_base": {k: str(v) for k, v in self.initial_base.items()},
                "bootstrap_cost": str(self.bootstrap_cost),
                "bootstrap_quote_conversion_fee": str(self.bootstrap_quote_conversion_fee),
                "bootstrap_seed_fee": str(self.bootstrap_seed_fee),
                "seed_equity0": str(self.seed_equity0),
                "start_ts": self.start_ts,
                "ready_ts": self.ready_ts,
                "next_oid": self.next_oid,
                "stats": {},
            }
            for a, s in self.stats.items():
                state["stats"][a] = {
                    "active": s.active,
                    "initial_base": str(s.initial_base),
                    "base_qty": str(s.base_qty),
                    "fills_buy": s.fills_buy,
                    "fills_sell": s.fills_sell,
                    "fill_notional_usdc": str(s.fill_notional_usdc),
                    "matched_notional_usdc": str(s.matched_notional_usdc),
                    "cycles": s.cycles,
                    "maker_capture_usdc": str(s.maker_capture_usdc),
                    "maker_fees_usdc": str(s.maker_fees_usdc),
                    "realized_cycles_usdc": str(s.realized_cycles_usdc),
                    "markout_usdc": str(s.markout_usdc),
                    "markout_notional_usdc": str(s.markout_notional_usdc),
                }
            tmp = self.state_path.with_suffix(self.state_path.suffix + ".tmp")
            tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
            tmp.replace(self.state_path)
            self.last_save = time.time()

    # ---------- loops ----------

    def reporter_loop(self) -> None:
        next_status = time.time() + self.args.status
        next_report = time.time() + self.args.report
        while not self.stop_event.is_set():
            now = time.time()
            try:
                with self.lock:
                    if now >= next_status:
                        print(self.status_line(), flush=True)
                        next_status = now + self.args.status
                    if now >= next_report:
                        print(self.report(), flush=True)
                        next_report = now + self.args.report
            except Exception as e:
                print(f"{utc_text()} | WARN | reporter: {e}", flush=True)
            self.stop_event.wait(0.5)

    def run(self) -> None:
        self.initialize()
        if self.stop_event.is_set():
            return
        print()
        print(BOT_NAME + " — NESSUN ORDINE REALE")
        print(
            f"Capitale={self.capital} | assets={','.join(self.assets)} | max_active={self.max_active}"
        )
        print(
            f"Fee simulate maker/taker={self.maker_fee_bps}/{self.taker_fee_bps} bp | "
            "inventory target=2.500% hard=0.500-5.000%"
        )
        print(
            "Futures/leva: ASSENTI | fair cross-quote USDC<->USDT | "
            f"queue depth + participation {float(self.participation*100):.0f}%"
        )
        print(f"Stato: {self.state_path}")
        print("=" * 120)
        print(self.report(), flush=True)

        reporter = threading.Thread(target=self.reporter_loop, name="reporter", daemon=True)
        reporter.start()

        next_books = 0.0
        next_quotes = 0.0
        next_tape = 0.0
        next_depth = 0.0
        try:
            while not self.stop_event.is_set():
                now = time.time()
                with self.lock:
                    if now >= next_books:
                        ok = self.fetch_all_books()
                        next_books = now + max(5.0, self.args.poll)
                        if ok:
                            self.handle_resume_if_needed()
                            self.update_fair_history()
                            self.process_markouts()

                    if not self.rest.is_degraded() and now >= next_quotes:
                        self.refresh_quotes()
                        next_quotes = now + self.args.quote_refresh

                    if not self.rest.is_degraded() and now >= next_tape:
                        self.poll_one_tape()
                        next_tape = now + max(2.0, self.args.poll)

                    if not self.rest.is_degraded() and now >= next_depth:
                        self.refresh_one_depth()
                        next_depth = now + max(8.0, self.args.depth_refresh)

                    if now - self.last_save >= 30:
                        self.save_state()

                self.stop_event.wait(0.20)
        finally:
            self.stop_event.set()
            try:
                self.save_state()
            except Exception:
                pass
            print(f"{utc_text()} | INFO | [STOP] DEMO terminata; nessun ordine reale da cancellare.")


# ---------- self test ----------


def self_test() -> None:
    assert utc_now().tzinfo is not None
    assert utc_text().endswith("UTC")
    assert q_down(Decimal("1.239"), Decimal("0.01")) == Decimal("1.23")
    assert q_up(Decimal("1.231"), Decimal("0.01")) == Decimal("1.24")

    b = Book(Decimal("0.9999"), Decimal("10"), Decimal("1.0001"), Decimal("11"), time.time())
    assert b.mid == Decimal("1.0000")

    # Queue mechanics: no fill while queue is ahead; max participation after queue clears.
    o = VirtualOrder(
        oid=1,
        symbol="TESTUSDC",
        asset="TEST",
        quote="USDC",
        side="BUY",
        level=1,
        price=Decimal("10"),
        qty=Decimal("5"),
        remaining=Decimal("5"),
        created_ms=0,
        eligible_ms=0,
        queue_ahead=Decimal("3"),
    )
    available = Decimal("2")
    consumed = min(o.queue_ahead, available)
    o.queue_ahead -= consumed
    available -= consumed
    assert o.queue_ahead == Decimal("1") and available == 0

    # No private key / signed endpoints / order endpoint exists anywhere in source.
    src = Path(__file__).read_text(encoding="utf-8")
    forbidden = ["/api/v3/" + "order", "X-MEXC-" + "APIKEY", "api_" + "secret", "secret_" + "key"]
    for token in forbidden:
        assert token not in src

    # Infrastructure design assertions.
    assert "PRESERVED" in src
    assert "no retro-fill" in src
    assert "reporter_loop" in src
    assert "/api/v3/depth" in src
    assert "/api/v3/aggTrades" in src

    print(f"SELF-TEST {BOT_NAME}: SUPERATO")
    print("  OK UTC | OK no-real-order path | OK serialized REST | OK preserve-on-blackout design")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=BOT_NAME)
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--start", action="store_true")
    p.add_argument("--reset", action="store_true")
    p.add_argument("--capital", type=float, default=10000)
    p.add_argument("--assets", default="BTC,ETH,SOL,XRP,BCH,DOGE")
    p.add_argument("--max-active", type=int, default=5)
    p.add_argument("--maker-fee-bps", type=float, default=0.0)
    p.add_argument("--taker-fee-bps", type=float, default=5.0)
    p.add_argument("--min-edge-bps", type=float, default=0.10)
    p.add_argument("--full-edge-bps", type=float, default=0.75)
    p.add_argument("--risk-buffer-bps", type=float, default=0.15)
    p.add_argument("--lot-fraction", type=float, default=0.0125)
    p.add_argument("--participation", type=float, default=0.35)
    p.add_argument("--min-life", type=float, default=30.0)
    p.add_argument("--poll", type=float, default=2.0)
    p.add_argument("--quote-refresh", type=float, default=10.0)
    p.add_argument("--depth-ttl", type=float, default=45.0)
    p.add_argument("--depth-refresh", type=float, default=10.0)
    p.add_argument("--min-request-gap", type=float, default=1.5)
    p.add_argument("--timeout", type=float, default=8.0)
    p.add_argument("--status", type=float, default=30.0)
    p.add_argument("--report", type=float, default=300.0)
    p.add_argument("--state", default=DEFAULT_STATE)
    return p


def main() -> int:
    args = build_parser().parse_args()
    if args.self_test:
        self_test()
        return 0
    if not args.start:
        print("Usa --self-test oppure --start")
        return 2

    state_path = Path(args.state).expanduser().resolve()
    if args.reset and state_path.exists():
        state_path.unlink()

    eng = Engine(args)

    def stop_handler(signum: int, frame: Any) -> None:
        eng.stop_event.set()

    signal.signal(signal.SIGINT, stop_handler)
    signal.signal(signal.SIGTERM, stop_handler)
    eng.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
